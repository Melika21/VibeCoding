<?php
/**
 * Class RCS_Elementor_Elementor
 *
 * Elementor integration entry point.
 */
class RCS_Elementor_Elementor {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function init() {
        if ( ! class_exists( 'Elementor\Plugin' ) ) {
            return;
        }
        try {
            $elementor = \Elementor\Plugin::instance();
            if ( ! $elementor ) {
                return;
            }
            add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
            add_action( 'elementor/widgets/categories', array( $this, 'register_category' ) );
        } catch ( \Throwable $e ) {
            error_log( 'RCS Elementor init error: ' . $e->getMessage() );
        }
    }

    public function register_widgets( $widgets_manager ) {
        if ( class_exists( 'RCS_Elementor_FormWidget' ) ) {
            $widgets_manager->register( new RCS_Elementor_FormWidget() );
        }
    }

    public function register_category( $categories ) {
        $categories[] = array(
            'slug'  => 'rcs',
            'title' => __( 'Request & Coupon System', 'request-coupon-system' ),
        );
        return $categories;
    }
}
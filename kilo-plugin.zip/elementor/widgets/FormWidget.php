<?php
/**
 * Class RCS_Elementor_FormWidget
 *
 * Elementor widget for rendering forms.
 * Presentation layer only — no business logic.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( class_exists( 'Elementor\Widget_Base' ) ) :

class RCS_Elementor_FormWidget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'rcs_form';
    }

    public function get_title() {
        return __( 'Request Form', 'request-coupon-system' );
    }

    public function get_icon() {
        return 'eicon-form';
    }

    public function get_categories() {
        if ( class_exists( 'Elementor\Plugin' ) ) {
            $elementor = \Elementor\Plugin::instance();
            if ( $elementor && ! $elementor->elements_manager->has_registered_category( 'rcs' ) ) {
                return array( 'general' );
            }
        }
        return array( 'rcs' );
    }

    public function register_controls() {
        // Intentionally minimal at this stage.
    }

    protected function render() {
        // Intentionally minimal at this stage.
    }
}

endif;
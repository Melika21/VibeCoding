<?php
/**
 * Class RCS_Admin_Admin
 *
 * Admin integration entry point.
 */
class RCS_Admin_Admin {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function init() {
        $this->register_pages();
    }

    private function register_pages() {
        // Page registration is intentionally minimal at this stage.
    }
}
<?php
/**
 * Class RCS_Scheduler_Scheduler
 *
 * Manages scheduled tasks.
 */
class RCS_Scheduler_Scheduler {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function init() {
        add_action( 'rcs_coupon_expiry_reminder', array( $this, 'send_expiry_reminders' ) );
    }

    public function send_expiry_reminders() {
        // Intentionally empty at this stage.
    }
}
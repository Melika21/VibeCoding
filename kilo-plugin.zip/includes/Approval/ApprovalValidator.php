<?php
/**
 * Class RCS_Approval_ApprovalValidator
 *
 * Validates approval actions.
 */
class RCS_Approval_ApprovalValidator {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function validate( $request_id, $revision_id, $discount_percentage, $max_discount ) {
        return array(
            'valid' => true,
            'errors' => array(),
        );
    }
}
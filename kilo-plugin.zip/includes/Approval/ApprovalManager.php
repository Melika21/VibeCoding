<?php
/**
 * Class RCS_Approval_ApprovalManager
 *
 * Manages the approval workflow.
 */
class RCS_Approval_ApprovalManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function approve( $request_id, $revision_id, $discount_percentage, $max_discount, $expert_id ) {
        return null;
    }

    public function reject( $request_id, $revision_id, $reason, $expert_id ) {
        return null;
    }
}
<?php
/**
 * Class RCS_Approval_ExpertRole
 *
 * Expert role and capability helpers.
 */
class RCS_Approval_ExpertRole {

    const ROLE = 'rcs_expert';

    const CAP_VIEW_REQUESTS    = 'rcs_view_requests';
    const CAP_APPROVE_REQUESTS = 'rcs_approve_requests';
    const CAP_REJECT_REQUESTS  = 'rcs_reject_requests';
    const CAP_SET_DISCOUNT     = 'rcs_set_discount';
    const CAP_MANAGE_COUPONS   = 'rcs_manage_coupons';
    const CAP_RETRY_SMS        = 'rcs_retry_sms';
    const CAP_VIEW_LOGS        = 'rcs_view_logs';

    public static function is_expert( $user_id = 0 ) {
        if ( 0 === $user_id ) {
            $user_id = get_current_user_id();
        }
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return false;
        }
        return in_array( self::ROLE, (array) $user->roles, true );
    }

    public static function can_approve( $user_id = 0 ) {
        if ( 0 === $user_id ) {
            $user_id = get_current_user_id();
        }
        return user_can( $user_id, self::CAP_APPROVE_REQUESTS );
    }

    public static function can_reject( $user_id = 0 ) {
        if ( 0 === $user_id ) {
            $user_id = get_current_user_id();
        }
        return user_can( $user_id, self::CAP_REJECT_REQUESTS );
    }
}
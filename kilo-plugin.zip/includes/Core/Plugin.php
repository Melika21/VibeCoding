<?php
/**
 * Class RCS_Core_Plugin
 *
 * Central plugin bootstrap/orchestrator.
 * Coordinates modules; does NOT contain business logic.
 */
class RCS_Core_Plugin {

    private static $instance = null;

    private $modules = array();

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function init() {
        $this->load_integrations();
        $this->init_modules();
        $this->register_hooks();
        $this->init_admin();
        $this->init_frontend();
        $this->init_elementor();
        $this->init_scheduler();
    }

    private function load_integrations() {
        if ( class_exists( 'WooCommerce' ) && class_exists( 'RCS_Integrations_WooCommerce_WooCommerceIntegration' ) ) {
            $this->modules['woocommerce'] = RCS_Integrations_WooCommerce_WooCommerceIntegration::instance();
        }
        if ( class_exists( 'RCS_Integrations_SMSIr_SmsIrClient' ) ) {
            $this->modules['smsir'] = RCS_Integrations_SMSIr_SmsIrClient::instance();
        }
        if ( class_exists( 'Elementor\Elementor' ) && class_exists( 'RCS_Integrations_Elementor_ElementorIntegration' ) ) {
            $this->modules['elementor'] = RCS_Integrations_Elementor_ElementorIntegration::instance();
        }
    }

    private function init_modules() {
        if ( class_exists( 'RCS_Forms_FormManager' ) ) {
            $this->modules['forms'] = RCS_Forms_FormManager::instance();
        }
        if ( class_exists( 'RCS_Requests_RequestManager' ) ) {
            $this->modules['requests'] = RCS_Requests_RequestManager::instance();
        }
        if ( class_exists( 'RCS_Approval_ApprovalManager' ) ) {
            $this->modules['approval'] = RCS_Approval_ApprovalManager::instance();
        }
        if ( class_exists( 'RCS_Coupons_CouponManager' ) ) {
            $this->modules['coupons'] = RCS_Coupons_CouponManager::instance();
        }
        if ( class_exists( 'RCS_SMS_SmsManager' ) ) {
            $this->modules['sms'] = RCS_SMS_SmsManager::instance();
        }
        if ( class_exists( 'RCS_Logs_LogManager' ) ) {
            $this->modules['logs'] = RCS_Logs_LogManager::instance();
        }
        if ( class_exists( 'RCS_Reports_ReportManager' ) ) {
            $this->modules['reports'] = RCS_Reports_ReportManager::instance();
        }
    }

    private function register_hooks() {
        // Hook registration points are intentionally minimal at this stage.
    }

    private function init_admin() {
        if ( is_admin() && class_exists( 'RCS_Admin_Admin' ) ) {
            RCS_Admin_Admin::instance()->init();
        }
    }

    private function init_frontend() {
        if ( ! is_admin() && class_exists( 'RCS_Frontend_Frontend' ) ) {
            RCS_Frontend_Frontend::instance()->init();
        }
    }

    private function init_elementor() {
        if ( class_exists( 'Elementor\Elementor' ) && class_exists( 'RCS_Elementor_Elementor' ) ) {
            try {
                RCS_Elementor_Elementor::instance()->init();
            } catch ( \Throwable $e ) {
                error_log( 'RCS Elementor plugin init error: ' . $e->getMessage() );
            }
        }
    }

    private function init_scheduler() {
        if ( class_exists( 'RCS_Scheduler_Scheduler' ) ) {
            RCS_Scheduler_Scheduler::instance()->init();
        }
    }
}
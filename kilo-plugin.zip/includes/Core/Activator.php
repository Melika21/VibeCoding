<?php
/**
 * Class RCS_Core_Activator
 *
 * Responsibilities during plugin activation.
 * No business data is deleted here.
 */
class RCS_Core_Activator {

    public static function activate() {
        try {
            error_log( 'RCS: activation started' );
            self::check_requirements();
            error_log( 'RCS: requirements checked' );
            self::create_tables();
            error_log( 'RCS: tables created' );
            self::create_roles();
            error_log( 'RCS: roles created' );
            self::create_default_settings();
            error_log( 'RCS: default settings created' );
            self::register_scheduled_tasks();
            error_log( 'RCS: activation completed' );
        } catch ( \Throwable $e ) {
            error_log( 'RCS activation error: ' . $e->getMessage() );
        }
    }

    private static function check_requirements() {
        if ( class_exists( 'RCS_Core_Requirements' ) ) {
            $errors = RCS_Core_Requirements::check();
            if ( ! empty( $errors ) ) {
                set_site_transient( 'rcs_activation_requirements_errors', $errors, 300 );
            }
        }
    }

    private static function create_tables() {
        if ( class_exists( 'RCS_Database_Schema' ) ) {
            RCS_Database_Schema::create_tables();
        }
    }

    private static function create_roles() {
        add_role(
            'rcs_expert',
            __( 'Expert', 'request-coupon-system' ),
            array(
                'read'                       => true,
                'rcs_view_requests'          => true,
                'rcs_approve_requests'       => true,
                'rcs_reject_requests'        => true,
                'rcs_set_discount'           => true,
                'rcs_manage_coupons'         => true,
                'rcs_retry_sms'              => true,
                'rcs_view_logs'              => true,
            )
        );
    }

    private static function create_default_settings() {
        $defaults = array(
            'rcs_smsir_api_key'     => '',
            'rcs_smsir_secret_key'  => '',
            'rcs_smsir_pattern_id'  => '',
            'rcs_admin_phone'       => '',
            'rcs_coupon_expiry'     => 7 * 24 * HOUR_IN_SECONDS,
        );
        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $value );
            }
        }
    }

    private static function register_scheduled_tasks() {
        if ( ! wp_next_scheduled( 'rcs_coupon_expiry_reminder' ) ) {
            wp_schedule_event( time(), 'daily', 'rcs_coupon_expiry_reminder' );
        }
    }
}
<?php
/**
 * Class RCS_Core_Uninstaller
 *
 * Responsibilities during plugin uninstall.
 * Deletes plugin-owned data only.
 */
class RCS_Core_Uninstaller {

    public static function uninstall() {
        try {
            self::delete_tables();
            self::delete_options();
            self::delete_roles();
            self::delete_plugin_coupons();
            self::delete_plugin_data();
        } catch ( \Throwable $e ) {
            error_log( 'RCS uninstall error: ' . $e->getMessage() );
        }
    }

    private static function delete_tables() {
        global $wpdb;

        $tables = array(
            "{$wpdb->prefix}rcs_forms",
            "{$wpdb->prefix}rcs_form_fields",
            "{$wpdb->prefix}rcs_requests",
            "{$wpdb->prefix}rcs_request_revisions",
            "{$wpdb->prefix}rcs_plugin_coupons",
            "{$wpdb->prefix}rcs_sms",
            "{$wpdb->prefix}rcs_logs",
        );

        foreach ( $tables as $table ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore
        }
    }

    private static function delete_options() {
        $options = array(
            'rcs_smsir_api_key',
            'rcs_smsir_secret_key',
            'rcs_smsir_pattern_id',
            'rcs_admin_phone',
            'rcs_coupon_expiry',
        );
        foreach ( $options as $option ) {
            delete_option( $option );
        }
    }

    private static function delete_roles() {
        remove_role( 'rcs_expert' );
    }

    private static function delete_plugin_coupons() {
        if ( class_exists( 'RCS_Coupons_CouponManager' ) ) {
            RCS_Coupons_CouponManager::delete_all_plugin_coupons();
        }
    }

    private static function delete_plugin_data() {
        // Hook point for additional data cleanup.
        do_action( 'rcs_uninstall_cleanup' );
    }
}
<?php
/**
 * Class RCS_Core_Deactivator
 *
 * Responsibilities during plugin deactivation.
 * Does NOT delete plugin data.
 */
class RCS_Core_Deactivator {

    public static function deactivate() {
        try {
            self::unschedule_tasks();
        } catch ( \Throwable $e ) {
            error_log( 'RCS deactivation error: ' . $e->getMessage() );
        }
    }

    private static function unschedule_tasks() {
        $timestamp = wp_next_scheduled( 'rcs_coupon_expiry_reminder' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'rcs_coupon_expiry_reminder' );
        }
    }
}
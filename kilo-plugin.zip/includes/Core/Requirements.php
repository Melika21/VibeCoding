<?php
/**
 * Class RCS_Core_Requirements
 *
 * Checks the runtime environment before activation.
 */
class RCS_Core_Requirements {

    const MIN_PHP         = '7.4';
    const MIN_WP          = '6.0';
    const MIN_WOOCOMMERCE = '7.0';

    public static function check() {
        return self::collect_errors();
    }

    private static function collect_errors() {
        $errors = array();

        if ( version_compare( PHP_VERSION, self::MIN_PHP, '<' ) ) {
            $errors[] = sprintf(
                /* translators: 1: required PHP version 2: current PHP version */
                __( 'Request & Coupon System requires PHP %1$s or higher. You are running PHP %2$s.', 'request-coupon-system' ),
                self::MIN_PHP,
                PHP_VERSION
            );
        }

        if ( version_compare( $GLOBALS['wp_version'], self::MIN_WP, '<' ) ) {
            $errors[] = sprintf(
                /* translators: 1: required WordPress version 2: current WordPress version */
                __( 'Request & Coupon System requires WordPress %1$s or higher. You are running WordPress %2$s.', 'request-coupon-system' ),
                self::MIN_WP,
                $GLOBALS['wp_version']
            );
        }

        if ( ! class_exists( 'WooCommerce' ) ) {
            $errors[] = __( 'Request & Coupon System requires WooCommerce to be installed and active.', 'request-coupon-system' );
        } elseif ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, self::MIN_WOOCOMMERCE, '<' ) ) {
            $errors[] = sprintf(
                /* translators: 1: required WooCommerce version 2: current WooCommerce version */
                __( 'Request & Coupon System requires WooCommerce %1$s or higher. You are running WooCommerce %2$s.', 'request-coupon-system' ),
                self::MIN_WOOCOMMERCE,
                WC_VERSION
            );
        }

        return $errors;
    }

    private static function format_errors( $errors ) {
        $html = '<h1>' . esc_html__( 'Plugin Activation Error', 'request-coupon-system' ) . '</h1>';
        $html .= '<ul>';
        foreach ( $errors as $error ) {
            $html .= '<li>' . esc_html( $error ) . '</li>';
        }
        $html .= '</ul>';
        return $html;
    }
}
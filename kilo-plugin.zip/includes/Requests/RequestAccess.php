<?php
/**
 * Class RCS_Requests_RequestAccess
 *
 * Checks whether a user may access a request.
 */
class RCS_Requests_RequestAccess {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function can_edit( $request, $user_id = 0 ) {
        if ( ! $request ) {
            return false;
        }
        if ( 0 === $user_id ) {
            $user_id = get_current_user_id();
        }
        if ( (int) $request->user_id !== (int) $user_id ) {
            return false;
        }
        return RCS_Requests_RequestStatus::is_editable( $request->status );
    }

    public function can_view( $request, $user_id = 0 ) {
        if ( ! $request ) {
            return false;
        }
        if ( 0 === $user_id ) {
            $user_id = get_current_user_id();
        }
        return (int) $request->user_id === (int) $user_id;
    }
}
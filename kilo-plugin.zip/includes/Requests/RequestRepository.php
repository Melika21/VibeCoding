<?php
/**
 * Class RCS_Requests_RequestRepository
 *
 * Simple data-access class for requests.
 */
class RCS_Requests_RequestRepository {

    public static function find( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_requests WHERE id = %d", $id ) );
    }

    public static function find_by_user( $user_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_requests WHERE user_id = %d ORDER BY id DESC", $user_id ) );
    }

    public static function insert( $data ) {
        global $wpdb;
        $wpdb->insert( "{$wpdb->prefix}rcs_requests", $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        return $wpdb->update( "{$wpdb->prefix}rcs_requests", $data, array( 'id' => $id ) );
    }
}
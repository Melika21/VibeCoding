<?php
/**
 * Class RCS_Requests_RequestStatus
 *
 * Constants and helpers for request statuses.
 */
class RCS_Requests_RequestStatus {

    const DRAFT    = 'draft';
    const PENDING  = 'pending';
    const REJECTED = 'rejected';
    const APPROVED = 'approved';

    public static function all() {
        return array(
            self::DRAFT,
            self::PENDING,
            self::REJECTED,
            self::APPROVED,
        );
    }

    public static function is_editable( $status ) {
        return in_array( $status, array( self::DRAFT, self::REJECTED ), true );
    }

    public static function is_approved( $status ) {
        return self::APPROVED === $status;
    }
}
<?php
/**
 * Class RCS_Requests_RequestManager
 *
 * Manages request lifecycle.
 */
class RCS_Requests_RequestManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function create( $form_id, $user_id ) {
        return null;
    }

    public function get( $id ) {
        return null;
    }

    public function update_status( $id, $status ) {
        return null;
    }

    public function get_by_user( $user_id ) {
        return array();
    }
}
<?php
/**
 * Class RCS_Forms_FieldManager
 *
 * Manages fields belonging to a form.
 */
class RCS_Forms_FieldManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function get_fields( $form_id ) {
        return array();
    }

    public function add_field( $form_id, $field_data ) {
        return null;
    }

    public function update_field( $field_id, $field_data ) {
        return null;
    }

    public function delete_field( $field_id ) {
        return null;
    }
}
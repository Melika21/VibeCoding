<?php
/**
 * Class RCS_Forms_MultiStepManager
 *
 * Manages multi-step form state.
 */
class RCS_Forms_MultiStepManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function get_steps( $form_id ) {
        return array();
    }

    public function get_current_step( $form_id, $session ) {
        return 1;
    }
}
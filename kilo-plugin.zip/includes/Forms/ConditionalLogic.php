<?php
/**
 * Class RCS_Forms_ConditionalLogic
 *
 * Evaluates conditional logic for fields.
 */
class RCS_Forms_ConditionalLogic {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function evaluate( $logic, $data ) {
        return true;
    }
}
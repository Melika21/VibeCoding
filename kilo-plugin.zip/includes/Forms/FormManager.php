<?php
/**
 * Class RCS_Forms_FormManager
 *
 * Manages form lifecycle and rendering preparation.
 */
class RCS_Forms_FormManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function create( $data ) {
        return null;
    }

    public function update( $id, $data ) {
        return null;
    }

    public function delete( $id ) {
        return null;
    }

    public function get( $id ) {
        return null;
    }

    public function get_all() {
        return array();
    }
}
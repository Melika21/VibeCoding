<?php
/**
 * Class RCS_Forms_FormRepository
 *
 * Simple data-access class for forms.
 */
class RCS_Forms_FormRepository {

    public static function find( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_forms WHERE id = %d", $id ) );
    }

    public static function find_all() {
        global $wpdb;
        return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}rcs_forms ORDER BY id DESC" );
    }

    public static function insert( $data ) {
        global $wpdb;
        $wpdb->insert( "{$wpdb->prefix}rcs_forms", $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        return $wpdb->update( "{$wpdb->prefix}rcs_forms", $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        return $wpdb->delete( "{$wpdb->prefix}rcs_forms", array( 'id' => $id ) );
    }
}
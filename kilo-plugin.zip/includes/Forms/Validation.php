<?php
/**
 * Class RCS_Forms_Validation
 *
 * Validates submitted form data.
 */
class RCS_Forms_Validation {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function validate( $fields, $data ) {
        return array(
            'valid' => true,
            'errors' => array(),
        );
    }
}
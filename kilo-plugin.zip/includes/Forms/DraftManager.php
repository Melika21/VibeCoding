<?php
/**
 * Class RCS_Forms_DraftManager
 *
 * Manages form drafts.
 */
class RCS_Forms_DraftManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function save_draft( $form_id, $data, $user_id ) {
        return null;
    }

    public function get_draft( $form_id, $user_id ) {
        return null;
    }

    public function delete_draft( $form_id, $user_id ) {
        return null;
    }
}
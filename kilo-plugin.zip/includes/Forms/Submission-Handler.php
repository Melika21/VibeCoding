<?php
/**
 * Class RCS_Forms_SubmissionHandler
 *
 * Handles form submission and creates request revisions.
 */
class RCS_Forms_SubmissionHandler {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function submit( $form_id, $data, $user_id = 0 ) {
        return null;
    }
}
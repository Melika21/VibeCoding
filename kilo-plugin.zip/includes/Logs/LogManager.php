<?php
/**
 * Class RCS_Logs_LogManager
 *
 * Manages audit logging.
 */
class RCS_Logs_LogManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function log( $action, $context = array() ) {
        return null;
    }

    public function get( $id ) {
        return null;
    }

    public function get_by_request( $request_id ) {
        return array();
    }
}
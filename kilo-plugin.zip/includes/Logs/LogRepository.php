<?php
/**
 * Class RCS_Logs_LogRepository
 *
 * Simple data-access class for logs.
 */
class RCS_Logs_LogRepository {

    public static function insert( $data ) {
        global $wpdb;
        $wpdb->insert( "{$wpdb->prefix}rcs_logs", $data );
        return $wpdb->insert_id;
    }

    public static function find( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_logs WHERE id = %d", $id ) );
    }

    public static function find_by_request( $request_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_logs WHERE request_id = %d ORDER BY id DESC", $request_id ) );
    }
}
<?php
/**
 * Class RCS_Revisions_RevisionManager
 *
 * Manages revisions for a request.
 */
class RCS_Revisions_RevisionManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function create( $request_id, $data, $submitted_by ) {
        return null;
    }

    public function get( $id ) {
        return null;
    }

    public function get_by_request( $request_id ) {
        return array();
    }

    public function get_latest( $request_id ) {
        return null;
    }
}
<?php
/**
 * Class RCS_Revisions_RevisionRepository
 *
 * Simple data-access class for revisions.
 */
class RCS_Revisions_RevisionRepository {

    public static function find( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_request_revisions WHERE id = %d", $id ) );
    }

    public static function find_by_request( $request_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_request_revisions WHERE request_id = %d ORDER BY revision_number ASC", $request_id ) );
    }

    public static function find_latest( $request_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}rcs_request_revisions WHERE request_id = %d ORDER BY revision_number DESC LIMIT 1", $request_id ) );
    }

    public static function insert( $data ) {
        global $wpdb;
        $wpdb->insert( "{$wpdb->prefix}rcs_request_revisions", $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        return $wpdb->update( "{$wpdb->prefix}rcs_request_revisions", $data, array( 'id' => $id ) );
    }
}
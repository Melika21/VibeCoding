<?php
/**
 * Class RCS_Coupons_CouponManager
 *
 * Manages coupon lifecycle through WooCommerce.
 */
class RCS_Coupons_CouponManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function create_from_approval( $request_id, $revision_id, $discount_percentage, $max_discount, $user_id ) {
        return null;
    }

    public function update( $plugin_coupon_id, $args ) {
        return null;
    }

    public function disable( $plugin_coupon_id ) {
        return null;
    }

    public function get_by_request( $request_id ) {
        return null;
    }

    public function get_by_user( $user_id ) {
        return array();
    }

    public static function delete_all_plugin_coupons() {
        return null;
    }
}
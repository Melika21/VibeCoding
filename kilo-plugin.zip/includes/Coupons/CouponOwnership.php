<?php
/**
 * Class RCS_Coupons_CouponOwnership
 *
 * Enforces coupon ownership rules.
 */
class RCS_Coupons_CouponOwnership {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function verify( $plugin_coupon_id, $user_id ) {
        return false;
    }

    public function get_owner( $plugin_coupon_id ) {
        return 0;
    }
}
<?php
/**
 * Class RCS_Coupons_CouponValidator
 *
 * Validates coupon creation and update actions.
 */
class RCS_Coupons_CouponValidator {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function validate_create( $request_id, $discount_percentage, $max_discount ) {
        return array(
            'valid' => true,
            'errors' => array(),
        );
    }

    public function validate_update( $plugin_coupon_id, $args ) {
        return array(
            'valid' => true,
            'errors' => array(),
        );
    }
}
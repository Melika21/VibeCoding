<?php
/**
 * Class RCS_Coupons_WooCommerceCoupon
 *
 * Adapter for WooCommerce coupon operations.
 */
class RCS_Coupons_WooCommerceCoupon {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function create( $code, $args = array() ) {
        if ( class_exists( 'RCS_Integrations_WooCommerce_WooCommerceIntegration' ) ) {
            return RCS_Integrations_WooCommerce_WooCommerceIntegration::instance()->create_coupon( $code, $args );
        }
        return 0;
    }

    public function update( $id, $args = array() ) {
        if ( class_exists( 'RCS_Integrations_WooCommerce_WooCommerceIntegration' ) ) {
            return RCS_Integrations_WooCommerce_WooCommerceIntegration::instance()->update_coupon( $id, $args );
        }
        return 0;
    }

    public function disable( $id ) {
        return $this->update( $id, array( 'enabled' => false ) );
    }
}
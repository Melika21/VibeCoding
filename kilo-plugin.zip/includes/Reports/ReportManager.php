<?php
/**
 * Class RCS_Reports_ReportManager
 *
 * Manages reports.
 */
class RCS_Reports_ReportManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function get_summary() {
        return array();
    }

    public function get_by_date_range( $start, $end ) {
        return array();
    }
}
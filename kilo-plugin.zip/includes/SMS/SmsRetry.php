<?php
/**
 * Class RCS_SMS_SmsRetry
 *
 * Handles SMS retry logic.
 */
class RCS_SMS_SmsRetry {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function retry( $sms_id ) {
        return null;
    }

    public function can_retry( $sms_id ) {
        return true;
    }
}
<?php
/**
 * Class RCS_SMS_SmsStatus
 *
 * Constants and helpers for SMS statuses.
 */
class RCS_SMS_SmsStatus {

    const PENDING = 'pending';
    const SENT    = 'sent';
    const FAILED  = 'failed';

    public static function all() {
        return array(
            self::PENDING,
            self::SENT,
            self::FAILED,
        );
    }

    public static function is_failed( $status ) {
        return self::FAILED === $status;
    }

    public static function is_sent( $status ) {
        return self::SENT === $status;
    }
}
<?php
/**
 * Class RCS_SMS_SmsSender
 *
 * Sends SMS messages via the SMS.ir client.
 */
class RCS_SMS_SmsSender {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function send( $sms_id ) {
        if ( class_exists( 'RCS_Integrations_SMSIr_SmsIrClient' ) ) {
            return RCS_Integrations_SMSIr_SmsIrClient::instance()->send( '', '', array() );
        }
        return array(
            'success' => false,
            'message' => 'SMS.ir client is not available.',
        );
    }
}
<?php
/**
 * Class RCS_SMS_SmsManager
 *
 * Manages SMS lifecycle.
 */
class RCS_SMS_SmsManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function create( $data ) {
        return null;
    }

    public function send( $sms_id ) {
        return null;
    }

    public function retry( $sms_id ) {
        return null;
    }

    public function get( $sms_id ) {
        return null;
    }

    public function get_by_request( $request_id ) {
        return array();
    }
}
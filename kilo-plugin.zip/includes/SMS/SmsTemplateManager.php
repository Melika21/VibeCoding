<?php
/**
 * Class RCS_SMS_SmsTemplateManager
 *
 * Manages SMS template configuration.
 */
class RCS_SMS_SmsTemplateManager {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function get_pattern_id( $sms_type ) {
        return get_option( 'rcs_smsir_pattern_id', '' );
    }

    public function get_parameters( $sms_type, $context ) {
        return array();
    }
}
<?php
/**
 * Class RCS_Database_Installer
 *
 * Wrapper for database installation.
 */
class RCS_Database_Installer {

    public static function install() {
        if ( class_exists( 'RCS_Database_Schema' ) ) {
            RCS_Database_Schema::create_tables();
        }
    }
}
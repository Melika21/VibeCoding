<?php
/**
 * Class RCS_Database_Schema
 *
 * Creates plugin-specific database tables.
 * Uses dbDelta for idempotent table creation.
 */
class RCS_Database_Schema {

    public static function create_tables() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $tables = self::get_schema();

        foreach ( $tables as $sql ) {
            dbDelta( $sql );
        }
    }

    public static function get_schema() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        return array(
            "CREATE TABLE {$wpdb->prefix}rcs_forms (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                name varchar(255) NOT NULL,
                status varchar(20) NOT NULL DEFAULT 'active',
                settings longtext,
                created_by bigint(20) NOT NULL DEFAULT 0,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY idx_status (status)
            ) {$charset_collate};",

            "CREATE TABLE {$wpdb->prefix}rcs_form_fields (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                form_id bigint(20) NOT NULL,
                field_type varchar(50) NOT NULL,
                field_key varchar(100) NOT NULL,
                label varchar(255) NOT NULL DEFAULT '',
                options longtext,
                validation longtext,
                conditional_logic longtext,
                step int(11) NOT NULL DEFAULT 1,
                sort_order int(11) NOT NULL DEFAULT 0,
                field_settings longtext,
                PRIMARY KEY  (id),
                KEY idx_form_id (form_id),
                KEY idx_field_key (field_key)
            ) {$charset_collate};",

            "CREATE TABLE {$wpdb->prefix}rcs_requests (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                form_id bigint(20) NOT NULL,
                user_id bigint(20) NOT NULL,
                current_revision_id bigint(20) NOT NULL DEFAULT 0,
                status varchar(20) NOT NULL DEFAULT 'draft',
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                approved_at datetime NULL,
                rejected_at datetime NULL,
                PRIMARY KEY  (id),
                KEY idx_form_id (form_id),
                KEY idx_user_id (user_id),
                KEY idx_status (status)
            ) {$charset_collate};",

            "CREATE TABLE {$wpdb->prefix}rcs_request_revisions (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                request_id bigint(20) NOT NULL,
                revision_number int(11) NOT NULL DEFAULT 1,
                submitted_by bigint(20) NOT NULL,
                submitted_data longtext,
                status varchar(20) NOT NULL DEFAULT 'pending',
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                submitted_at datetime NULL,
                rejection_reason longtext,
                PRIMARY KEY  (id),
                KEY idx_request_id (request_id),
                KEY idx_status (status)
            ) {$charset_collate};",

            "CREATE TABLE {$wpdb->prefix}rcs_plugin_coupons (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                request_id bigint(20) NOT NULL,
                user_id bigint(20) NOT NULL,
                wc_coupon_id bigint(20) NOT NULL,
                coupon_code varchar(100) NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                approved_at datetime NULL,
                disabled_at datetime NULL,
                PRIMARY KEY  (id),
                UNIQUE KEY idx_request_id (request_id),
                KEY idx_user_id (user_id),
                KEY idx_wc_coupon_id (wc_coupon_id)
            ) {$charset_collate};",

            "CREATE TABLE {$wpdb->prefix}rcs_sms (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                request_id bigint(20) NOT NULL,
                user_id bigint(20) NOT NULL,
                recipient varchar(50) NOT NULL DEFAULT '',
                sms_type varchar(50) NOT NULL,
                pattern_id varchar(100) NOT NULL DEFAULT '',
                parameters longtext,
                status varchar(20) NOT NULL DEFAULT 'pending',
                provider_response longtext,
                error_info longtext,
                retry_count int(11) NOT NULL DEFAULT 0,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                sent_at datetime NULL,
                last_retry_at datetime NULL,
                PRIMARY KEY  (id),
                KEY idx_request_id (request_id),
                KEY idx_status (status),
                KEY idx_sms_type (sms_type)
            ) {$charset_collate};",

            "CREATE TABLE {$wpdb->prefix}rcs_logs (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                actor_user_id bigint(20) NOT NULL DEFAULT 0,
                actor_role varchar(100) NOT NULL DEFAULT '',
                action varchar(100) NOT NULL,
                request_id bigint(20) NOT NULL DEFAULT 0,
                revision_id bigint(20) NOT NULL DEFAULT 0,
                coupon_id bigint(20) NOT NULL DEFAULT 0,
                sms_id bigint(20) NOT NULL DEFAULT 0,
                ip_address varchar(45) NOT NULL DEFAULT '',
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                result varchar(20) NOT NULL DEFAULT 'success',
                error longtext,
                PRIMARY KEY  (id),
                KEY idx_action (action),
                KEY idx_request_id (request_id),
                KEY idx_created_at (created_at)
            ) {$charset_collate};",
        );
    }
}
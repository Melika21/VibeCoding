<?php
/**
 * Class RCS_Integrations_Elementor_ElementorIntegration
 *
 * Isolates Elementor integration from the rest of the application.
 */
class RCS_Integrations_Elementor_ElementorIntegration {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function is_available() {
        return class_exists( 'Elementor\Elementor' );
    }
}
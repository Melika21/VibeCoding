<?php
/**
 * Class RCS_Integrations_SMSIr_SmsIrClient
 *
 * Isolates SMS.ir communication from the rest of the application.
 */
class RCS_Integrations_SMSIr_SmsIrClient {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function is_available() {
        return true;
    }

    public function get_api_key() {
        return get_option( 'rcs_smsir_api_key', '' );
    }

    public function get_secret_key() {
        return get_option( 'rcs_smsir_secret_key', '' );
    }

    public function send( $pattern_id, $recipient, $parameters = array() ) {
        return array(
            'success' => false,
            'message' => 'SMS.ir client is not configured.',
            'data'    => null,
        );
    }
}
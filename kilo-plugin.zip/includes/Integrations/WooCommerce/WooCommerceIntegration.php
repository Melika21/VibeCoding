<?php
/**
 * Class RCS_Integrations_WooCommerce_WooCommerceIntegration
 *
 * Isolates WooCommerce integration from the rest of the application.
 */
class RCS_Integrations_WooCommerce_WooCommerceIntegration {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function is_available() {
        return class_exists( 'WooCommerce' );
    }

    public function get_coupon( $id ) {
        if ( ! $this->is_available() ) {
            return null;
        }
        return new WC_Coupon( $id );
    }

    public function create_coupon( $code, $args = array() ) {
        if ( ! $this->is_available() ) {
            return 0;
        }
        $coupon = new WC_Coupon();
        $coupon->set_code( $code );
        foreach ( $args as $key => $value ) {
            $setter = 'set_' . $key;
            if ( method_exists( $coupon, $setter ) ) {
                $coupon->$setter( $value );
            }
        }
        $coupon->save();
        return $coupon->get_id();
    }

    public function update_coupon( $id, $args = array() ) {
        if ( ! $this->is_available() ) {
            return 0;
        }
        $coupon = new WC_Coupon( $id );
        foreach ( $args as $key => $value ) {
            $setter = 'set_' . $key;
            if ( method_exists( $coupon, $setter ) ) {
                $coupon->$setter( $value );
            }
        }
        $coupon->save();
        return $coupon->get_id();
    }
}
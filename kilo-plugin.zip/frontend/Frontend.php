<?php
/**
 * Class RCS_Frontend_Frontend
 *
 * Frontend integration entry point.
 */
class RCS_Frontend_Frontend {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    public function init() {
        // Intentionally minimal at this stage.
    }
}